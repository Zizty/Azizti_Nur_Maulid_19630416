  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <?= $this->session->flashdata('pesan_notifikasi'); ?>
      </section>
      <!-- Main content -->
      <section class="content">
          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title">Ubah <?= $judul; ?></h3>
              </div>
              <div class="card-body col-md-6">
                  <form id="formTambah" action="" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="id_stanmeterganti" class="form-control" id="id_stanmeterganti" value="<?= $stanmeterganti['id_stanmeterganti']; ?>">
                      <div class="modal-body">
                          <div class="form-group">
                              <label>Tanggal</label>
                              <div class="input-group date" id="reservationdate1" data-target-input="nearest">
                                  <input type="text" class="form-control datetimepicker-input" name="tanggal" data-target="#reservationdate1" value="<?= date('d-m-Y', strtotime($stanmeterganti['tanggal'])); ?>" data-toggle="datetimepicker">
                                  <div class="input-group-append" data-target="#reservationdate1" data-toggle="datetimepicker">
                                      <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                  </div>
                              </div>
                          </div>
                          <div class="form-group">
                              <label for="no_pelanggan">Nomor Pelanggan</label>
                              <input type="text" name="no_pelanggan" class="form-control" id="no_pelanggan" value="<?= $pelanggan['no_pelanggan']; ?>" placeholder="Isi Nomor Pelanggan" readonly>
                              <small class="text-danger"><?= form_error('no_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="id_pelanggan">Nama Pelanggan</label>
                              <input type="hidden" name="id_pelanggan" class="form-control" id="id_pelanggan" value="<?= $pelanggan['id_pelanggan']; ?>" placeholder="Isi Id Pelanggan" readonly>
                              <input type="text" name="nama_pelanggan" class="form-control" id="nama_pelanggan" value="<?= $pelanggan['nama_pelanggan']; ?>" placeholder="Isi Nama Pelanggan" readonly>
                              <small class="text-danger"><?= form_error('id_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="id_pegawai">Pilih Petugas</label>
                              <select class="form-control select2 select2-hidden-accessible" name="id_pegawai" style="width: 100%;" tabindex="-1" aria-hidden="true">
                                  <?php foreach ($petugas as $list) :
                                        if ($list['id_pegawai'] !== '1') {
                                    ?>

                                          <?php
                                            if ($list['id_pegawai'] == $stanmeterganti['id_pegawai']) {

                                            ?>
                                              <option value="<?= $list['id_pegawai']; ?>" selected="selected"><?= $list['nama_pegawai']; ?></option>
                                          <?php
                                            } else {
                                            ?>
                                              <option value="<?= $list['id_pegawai']; ?>"><?= $list['nama_pegawai']; ?></option>
                                          <?php
                                            }
                                            ?>
                                  <?php }
                                    endforeach; ?>
                              </select>
                          </div>
                          <div class="form-group">
                              <label for="keterangan">Keterangan</label>
                              <input type="text" name="keterangan" class="form-control" id="keterangan" value="<?= $stanmeterganti['keterangan']; ?>" placeholder="Isi keterangan">
                              <small class="text-danger"><?= form_error('keterangan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="file">Unggah File Pergantian (format : gif|jpg|jpeg|png) <i class="text-prmary"><a href="<?= base_url('files/') . $stanmeterganti['file']; ?>" target="_blank">File Lama</a></i></label>
                              <input type="file" class="form-control" id="file" name="file">
                              <small class="text-danger"><?= form_error('file'); ?></small>
                          </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                          <button type="button" class="btn btn-warning" onclick="window.location='<?= base_url('petugas/stanmeterganti'); ?>'"><i class="fa fa-arrow-left"></i> Kembali</button>
                          <button type="submit" class="btn btn-primary" onclick="return confirm('Anda yakin ingin menambah data');"><i class="fa fa-save"></i> Simpan</button>
                      </div>
                  </form>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->