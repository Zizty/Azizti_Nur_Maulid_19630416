  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <!-- NOTIF FLASH DISINI-->
          <?php if ($this->session->flashdata()) : ?>
              <!-- right column -->
              <div class="col-md-12">
                  <div class="alert alert-success alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h5><i class="icon fas fa-check"></i> Notifkasi!</h5>
                      Data berhasil <?= $this->session->flashdata('flashdata'); ?>
                  </div>
              </div>
              <!--/.col (right) -->
          <?php endif; ?>
      </section>

      <!-- Main content -->
      <section class="content">
          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title"><?= $judul; ?></h3>
              </div>
              <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                      <thead>
                          <tr>
                              <th>No</th>
                              <th>Tanggal Tagihan</th>
                              <th>No Pelanggan</th>
                              <th>Nama Pelanggan</th>
                              <th>Pemakaian m<sup>3</sup></th>
                              <th>Total Pemakaian</th>
                              <th>Denda</th>
                              <th>Total Biaya</th>
                              <th>Status</th>
                              <th>Aksi</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php
                            $no = 1;
                            $beban = 0;
                            foreach ($stanmeter as $ft) :
                                $pelanggan = $this->Pelanggan_model->getpelangganById($ft['id_pelanggan']);
                                $golongan = $this->Golongan_model->getgolonganById($pelanggan['id_golongan']);
                                $petugas = $this->Pegawai_model->getPegawaiById($ft['id_pegawai']);

                                $beban = $golongan['beban'];
                                $selisih = $ft['indeks_sekarang'] - $ft['indeks_sebelum'];
                                if ($selisih < 501) {
                                    $kubik = 0.5;
                                    $total = $kubik * $beban;
                                } else {
                                    $hasilkubik = $selisih / 1000; //1,9
                                    $koma = ".";
                                    $tidakadakoma = strpos($hasilkubik, $koma);
                                    if ($tidakadakoma == false) {
                                        $kubik = $hasilkubik;
                                        $total = $hasilkubik * $beban;
                                    } else {
                                        $nilaibelakangkoma = substr($hasilkubik, strpos($hasilkubik, ".") + 1);
                                        $nilaibelakangkoma = '0.' . $nilaibelakangkoma;
                                        if ($nilaibelakangkoma < 0.5) {
                                            $kubik = strtok($hasilkubik, '.') . '.5';
                                            $total = $kubik * $beban;
                                        } else {
                                            $kubik = strtok($hasilkubik, '.') + 1;
                                            $total = $kubik * $beban;
                                        }
                                    }
                                }
                                $pembayaran = $this->db->get_where('pembayaran', ['id_stanmeter' => $ft['id_stanmeter']]);
                                if ($pembayaran->num_rows() > 0) {
                                    $datapembayaran = $this->db->get_where('pembayaran', ['id_stanmeter' => $ft['id_stanmeter']])->row_array();
                                    $id_pembayaran = $datapembayaran['id_pembayaran'];
                                }
                                $tgl1 = strtotime($ft['tanggal_tagihan']);
                                $tgl2 = strtotime(date('Y-m-d'));

                                $jarak = $tgl2 - $tgl1;

                                $lama = $jarak / 60 / 60 / 24;
                                if ($tgl1 < $tgl2) {
                                    if ($lama <= 30) {
                                        $denda = 20000;
                                    } else {
                                        $lama = $lama / 30;
                                        $lama = floor($lama);
                                        $denda = $lama * 20000;
                                    }
                                } else {
                                    $denda = 0;
                                }
                            ?>
                              <tr>
                                  <td><?= $no; ?></td>
                                  <td><?= tanggal_indo($ft['tanggal_tagihan']); ?></td>
                                  <td><?= $pelanggan['no_pelanggan']; ?></td>
                                  <td><?= $pelanggan['nama_pelanggan']; ?></td>
                                  <td><?= $kubik; ?> m<sup>3</sup></td>
                                  <td><?= rupiah($total); ?></td>
                                  <td><?= rupiah($denda); ?></td>
                                  <td><?= rupiah($total + $denda); ?></td>
                                  <td><?= status_tagihan($ft['id_status']); ?></td>
                                  <td>
                                      <a href="<?= base_url(); ?>register/detail_tagihan/<?= $ft['id_stanmeter']; ?>"><button type="button" class="btn btn-primary btn-sm"><i class="fa fa-info"></i> Detail</button></a>
                                      <?php
                                        if ($ft['id_status'] == '0') {

                                        ?>
                                          <a href="<?= base_url('register/tambah_tagihan/' . $ft['id_stanmeter']); ?>"><button type="button" class="btn btn-success btn-sm"><i class="fa fa-plus"></i> Bayar Tagihan</button></a>
                                      <?php
                                        }
                                        if ($ft['id_status'] == '1') {
                                        ?>
                                          <a href="<?= base_url(); ?>register/hapus_tagihan/<?= $datapembayaran['id_pembayaran']; ?>"><button type="button" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus data ini');"><i class="fa fa-trash"></i> Hapus</button></a>
                                      <?php  } ?>
                                  </td>
                              </tr>
                          <?php $no++;
                            endforeach; ?>
                      </tbody>
                      <tfoot>
                          <tr>
                              <th>No</th>
                              <th>Tanggal Tagihan</th>
                              <th>No Pelanggan</th>
                              <th>Nama Pelanggan</th>
                              <th>Pemakaian m<sup>3</sup></th>
                              <th>Total Pemakaian</th>
                              <th>Denda</th>
                              <th>Total Biaya</th>
                              <th>Status</th>
                              <th>Aksi</th>
                          </tr>
                      </tfoot>
                  </table>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->