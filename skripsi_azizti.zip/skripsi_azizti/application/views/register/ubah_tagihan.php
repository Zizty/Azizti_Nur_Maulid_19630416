  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <?= $this->session->flashdata('pesan_notifikasi'); ?>
      </section>
      <!-- Main content -->
      <section class="content">
          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title">Ubah <?= $judul; ?></h3>
              </div>
              <div class="card-body col-md-6">
                  <form id="formTambah" action="" method="post" enctype="multipart/form-data">
                      <input type="hidden" name="id_pembayaran" class="form-control" id="id_pembayaran" value="<?= $pembayaran['id_pembayaran']; ?>" readonly>
                      <div class="modal-body">
                          <div class="form-group">
                              <label>Tanggal</label>
                              <div class="input-group date" id="reservationdate1" data-target-input="nearest">
                                  <input type="text" class="form-control datetimepicker-input" name="tanggal" data-target="#reservationdate1" value="<?= date('d-m-Y', strtotime($pembayaran['tanggal'])); ?>" data-toggle="datetimepicker">
                                  <div class="input-group-append" data-target="#reservationdate1" data-toggle="datetimepicker">
                                      <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                  </div>
                              </div>
                          </div>
                          <?php
                            $pelanggan = $this->Pelanggan_model->getpelangganById($stanmeter['id_pelanggan']);
                            $golongan = $this->Golongan_model->getgolonganById($pelanggan['id_golongan']);
                            $petugas = $this->Pegawai_model->getPegawaiById($stanmeter['id_pegawai']);

                            $beban = $golongan['beban'];
                            $selisih = $stanmeter['indeks_sekarang'] - $stanmeter['indeks_sebelum'];
                            if ($selisih < 501) {
                                $kubik = 0.5;
                                $total = $kubik * $beban;
                            } else {
                                $hasilkubik = $selisih / 1000; //1,9
                                $koma = ".";
                                $tidakadakoma = strpos($hasilkubik, $koma);
                                if ($tidakadakoma == false) {
                                    $kubik = $hasilkubik;
                                    $total = $hasilkubik * $beban;
                                } else {
                                    $nilaibelakangkoma = substr($hasilkubik, strpos($hasilkubik, ".") + 1);
                                    $nilaibelakangkoma = '0.' . $nilaibelakangkoma;
                                    if ($nilaibelakangkoma < 0.5) {
                                        $kubik = strtok($hasilkubik, '.') . '.5';
                                        $total = $kubik * $beban;
                                    } else {
                                        $kubik = strtok($hasilkubik, '.') + 1;
                                        $total = $kubik * $beban;
                                    }
                                }
                            }
                            ?>
                          <div class="form-group">
                              <label for="no_pelanggan">No Pelanggan</label>
                              <input type="text" name="keterangan" class="form-control" id="no_pelanggan" value="<?= $pelanggan['no_pelanggan']; ?>" readonly>
                              <small class="text-danger"><?= form_error('no_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="nama_pelanggan">Pelanggan</label>
                              <input type="text" name="keterangan" class="form-control" id="nama_pelanggan" value="<?= $pelanggan['nama_pelanggan']; ?>" readonly>
                              <small class="text-danger"><?= form_error('nama_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="total_pemakaian">Biaya Pemakaian</label>
                              <input type="text" name="biaya_pemakaian" class="form-control" id="biaya_pemakaian" value="<?= rupiah($total); ?>" readonly>
                              <small class="text-danger"><?= form_error('nama_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="biaya_admin">Biaya Admin</label>
                              <input type="text" name="biaya_admin" class="form-control" id="biaya_admin" value="<?= rupiah('2500'); ?>" readonly>
                              <small class="text-danger"><?= form_error('nama_pelanggan'); ?></small>
                          </div>
                          <?php
                            $total_tagihan = $total + 2500;
                            ?>
                          <div class="form-group">
                              <label for="total_tagihan">Total Tagihan</label>
                              <input type="text" name="total_tagihan" class="form-control" id="total_tagihan" value="<?= rupiah($total_tagihan); ?>" readonly>
                              <small class="text-danger"><?= form_error('nama_pelanggan'); ?></small>
                          </div>
                          <div class="form-group">
                              <label for="keterangan">Keterangan</label>
                              <input type="text" name="keterangan" class="form-control" id="keterangan" value="" placeholder="Isi keterangan">
                              <small class="text-danger"><?= form_error('keterangan'); ?></small>
                          </div>
                      </div>
                      <div class="modal-footer justify-content-between">
                          <button type="button" class="btn btn-warning" onclick="window.location='<?= base_url('register/stanmeterhilang'); ?>'"><i class="fa fa-arrow-left"></i> Kembali</button>
                          <button type="submit" class="btn btn-primary" onclick="return confirm('Anda yakin ingin menambah data');"><i class="fa fa-save"></i> Simpan</button>
                      </div>
                  </form>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->