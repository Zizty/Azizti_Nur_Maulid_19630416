  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
          <!-- NOTIF FLASH DISINI-->
      </section>

      <!-- Main content -->
      <section class="content">

          <!-- Default box -->
          <div class="card">
              <div class="card-header">
                  <h3 class="card-title"><?= $judul; ?></h3>
              </div>
              <div class="card-body">
                  <div class="alert alert-primary alert-dismissible">
                      <h4 align="center"><?= strtoupper($profil['nama_profil']); ?><br /><?= $profil['nama_aplikasi']; ?></h4>
                  </div>
                  <div class="row">
                      <div class="col-md-3 col-sm-6 col-12">
                          <div class="info-box">
                              <span class="info-box-icon bg-info"><i class="fas fa fa-user"></i></span>

                              <div class="info-box-content">
                                  <a href="<?= base_url('master/pegawai'); ?>"><span class="info-box-text">Pegawai</span>
                                      <span class="info-box-number"><?= $masterpegawai->num_rows(); ?></span></a>
                              </div>
                              <!-- /.info-box-content -->
                          </div>
                          <!-- /.info-box -->
                      </div>
                      <!-- /.col -->
                      <div class="col-md-3 col-sm-6 col-12">
                          <div class="info-box">
                              <span class="info-box-icon bg-info"><i class="fas fa fa-file"></i></span>

                              <div class="info-box-content">
                                  <a href="<?= base_url('master/kecamatan'); ?>"><span class="info-box-text">Kecamatan</span>
                                      <span class="info-box-number"></span><?= $masterkecamatan->num_rows(); ?></a>
                              </div>
                              <!-- /.info-box-content -->
                          </div>
                          <!-- /.info-box -->
                      </div>
                      <!-- /.col -->
                      <div class="col-md-3 col-sm-6 col-12">
                          <div class="info-box">
                              <span class="info-box-icon bg-info"><i class="fa fa-user"></i></span>

                              <div class="info-box-content">
                                  <a href="<?= base_url('register/pelanggan'); ?>"><span class="info-box-text">Pelanggan</span>
                                      <span class="info-box-number"></span><?= $masterpelanggan->num_rows(); ?></a>
                              </div>
                              <!-- /.info-box-content -->
                          </div>
                          <!-- /.info-box -->
                      </div>
                      <!-- /.col -->
                      <div class="col-md-3 col-sm-6 col-12">
                          <div class="info-box">
                              <span class="info-box-icon bg-info"><i class="fa fa-file"></i></span>

                              <div class="info-box-content">
                                  <a href="<?= base_url('register/stanmeter'); ?>"><span class="info-box-text">Stan Meter</span>
                                      <span class="info-box-number"><?= $masterstanmeter->num_rows(); ?></span></a>
                              </div>
                              <!-- /.info-box-content -->
                          </div>
                          <!-- /.info-box -->
                      </div>
                      <!-- /.col -->
                  </div>
                  <div class="card bg-primary text-white shadow mt-4">
                      <div class="card-body">
                          <p>
                              <b>Visi :</b><br />

                              <strong></strong><i>“Menjadikan Perusahaan Daerah Air Minum Kabupaten Hulu Sungai Selatan yang terbaik dikelasnya dengan mengedepankan pelayanan prima dan kepuasan masyarakat”</i></strong><br /><br />

                              <b>Misi :</b><br />

                              <strong>Mewujudkan Perusahaan Daerah Air Minum Kabupaten Hulu Sungai Selatan yang sehat dan berkembang serta produktif dengan mengutamakan peningkatan standar mutu pelayanan untuk kesejahteraan masyarakat Hulu Sungai Selatan</strong>

                          </p>
                      </div>
                  </div>
              </div>

          </div>
          <!-- /.card-body -->

          <!-- /.card -->

      </section>
      <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <script>
      //-------------
      //- PIE CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
      var pieData = donutData;
      var pieOptions = {
          maintainAspectRatio: false,
          responsive: true,
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      new Chart(pieChartCanvas, {
          type: 'pie',
          data: pieData,
          options: pieOptions
      })
  </script>