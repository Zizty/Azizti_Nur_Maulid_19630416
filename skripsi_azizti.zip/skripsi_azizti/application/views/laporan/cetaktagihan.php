  <!-- Main content -->
  <div class="invoice">
      <!-- title row -->
      <div class="row">
          <div class="col-12" align="center">
              <table width="80%" align="center">
                  <tr>
                      <td rowspan="2" align="right"><img src="<?= base_url('assets/dist/img/' . $profil['logo']); ?>" height="120" width="120" /></td>
                  </tr>
                  <tr>
                      <td align="center">
                          <h4><?= $profil['nama_profil']; ?></h4>
                          <p>Alamat : <?= $profil['alamat']; ?>. Telp :<?= $profil['telepon']; ?>. Kodepos : <?= $profil['kodepos']; ?> <br />
                              Email : <?= $profil['email']; ?>. Website : <?= $profil['website']; ?></p>
                          <h4>
                              Laporan <?= $judul; ?><br />
                              <?= "Periode : " . tanggal_indo($dariTanggal) . " s.d " . tanggal_indo($sampaiTanggal); ?>
                          </h4>
                      </td>
                  </tr>
              </table>
          </div>
      </div>
      <hr />

      <!-- Table row -->
      <div class="row">
          <div class="col-12 table-responsive">
              <table class="table table-striped">
                  <thead>
                      <tr>
                          <th>No</th>
                          <th>Tanggal Tagihan</th>
                          <th>No Pelanggan</th>
                          <th>Nama Pelanggan</th>
                          <th>Pemakaian m<sup>3</sup></th>
                          <th>Total Pemakaian</th>
                          <th>Denda</th>
                          <th>Total Biaya</th>
                          <th>Status</th>
                      </tr>
                  </thead>
                  <tbody>
                      <?php
                        $no = 1;
                        $beban = 0;
                        foreach ($filter as $ft) :
                            $pelanggan = $this->Pelanggan_model->getpelangganById($ft['id_pelanggan']);
                            $golongan = $this->Golongan_model->getgolonganById($pelanggan['id_golongan']);
                            $petugas = $this->Pegawai_model->getPegawaiById($ft['id_pegawai']);

                            $beban = $golongan['beban'];
                            $selisih = $ft['indeks_sekarang'] - $ft['indeks_sebelum'];
                            if ($selisih < 501) {
                                $kubik = 0.5;
                                $total = $kubik * $beban;
                            } else {
                                $hasilkubik = $selisih / 1000; //1,9
                                $koma = ".";
                                $tidakadakoma = strpos($hasilkubik, $koma);
                                if ($tidakadakoma == false) {
                                    $kubik = $hasilkubik;
                                    $total = $hasilkubik * $beban;
                                } else {
                                    $nilaibelakangkoma = substr($hasilkubik, strpos($hasilkubik, ".") + 1);
                                    $nilaibelakangkoma = '0.' . $nilaibelakangkoma;
                                    if ($nilaibelakangkoma < 0.5) {
                                        $kubik = strtok($hasilkubik, '.') . '.5';
                                        $total = $kubik * $beban;
                                    } else {
                                        $kubik = strtok($hasilkubik, '.') + 1;
                                        $total = $kubik * $beban;
                                    }
                                }
                            }
                            $pembayaran = $this->db->get_where('pembayaran', ['id_stanmeter' => $ft['id_stanmeter']]);
                            if ($pembayaran->num_rows() > 0) {
                                $datapembayaran = $this->db->get_where('pembayaran', ['id_stanmeter' => $ft['id_stanmeter']])->row_array();
                                $id_pembayaran = $datapembayaran['id_pembayaran'];
                            }
                            $tgl1 = strtotime($ft['tanggal_tagihan']);
                            $tgl2 = strtotime(date('Y-m-d'));

                            $jarak = $tgl2 - $tgl1;

                            $lama = $jarak / 60 / 60 / 24;
                            if ($tgl1 < $tgl2) {
                                if ($lama <= 30) {
                                    $denda = 20000;
                                } else {
                                    $lama = $lama / 30;
                                    $lama = floor($lama);
                                    $denda = $lama * 20000;
                                }
                            } else {
                                $denda = 0;
                            }
                        ?>
                          <tr>
                              <td><?= $no; ?></td>
                              <td><?= tanggal_indo($ft['tanggal']); ?></td>
                              <td><?= $pelanggan['no_pelanggan']; ?></td>
                              <td><?= $pelanggan['nama_pelanggan']; ?></td>
                              <td><?= $kubik; ?> m<sup>3</sup></td>
                              <td><?= rupiah($total); ?></td>
                              <td><?= rupiah($denda); ?></td>
                              <td><?= rupiah($total + $denda); ?></td>
                              <td><?= status_tagihan($ft['id_status']); ?></td>
                          </tr>
                      <?php $no++;
                        endforeach; ?>
                  </tbody>
              </table>
          </div>
          <!-- /.col -->
      </div>
      <!-- /.row -->
      <div class="row">
          <!-- accepted payments column -->
          <div class="col-6">

          </div>
          <!-- /.col -->
          <div class="col-6">
              <?php
                $pejabatttd = $this->db->get_where('pejabat_ttd', [
                    'aktif' => '1'
                ])->row_array();
                $nip_pejabattd = $pejabatttd['nip'];
                $nama_pejabattd = $pejabatttd['nama_pegawai'];
                $id_jabatanttd = $pejabatttd['id_jabatan'];
                $jabatanttd = $this->db->get_where('jabatan', ['id_jabatan' => $id_jabatanttd])->row_array();
                $nama_jabatanttd = $jabatanttd['nama_jabatan'];
                ?>
              <table align="right" width="60%">
                  <tr align="center">
                      <td>Kandangan, <?= tanggal_indo(date('Y-m-d')); ?></td>
                  </tr>
                  <tr align="center">
                      <td><?= $nama_jabatanttd; ?><br /><br /><br /></td>
                  </tr>
                  <tr align="center">
                      <td><b><u><?= $nama_pejabattd ?></u></b></td>
                  </tr>
                  <tr align="center">
                      <td><b><?= 'NIP. ' . $nip_pejabattd ?></b></td>
                  </tr>
              </table>
          </div>
          <!-- /.col -->
      </div>
      <!-- /.row -->
  </div>