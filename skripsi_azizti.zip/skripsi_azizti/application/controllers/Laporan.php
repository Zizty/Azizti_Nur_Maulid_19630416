<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Laporan extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();

        $this->load->model('Profil_model');
        $this->load->model('Menu_model');
        $this->load->model('Submenu_model');
        $this->load->model('Level_model');
        $this->load->model('Aksesmenu_model');
        $this->load->model('Pengguna_model');
        $this->load->model('Jabatan_model');
        $this->load->model('Pegawai_model');

        $this->load->model('Golongan_model');
        $this->load->model('Kecamatan_model');
        $this->load->model('Pelanggan_model');
        $this->load->model('Pembayaran_model');
        check_login();
    }

    //LAPORAN INDEX
    public function index()
    {

        redirect(base_url());
    }
    // PEGAWAI
    public function pegawai()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pegawai';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterpegawai'] = $this->db->get('pegawai')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('id_pegawai', 'Pegawai', 'required');
        //$this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $data['filter'] = $this->db->query('SELECT * FROM pegawai ORDER BY id_pegawai ASC')->result_array();

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pegawai', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['input_idpegawai'] = $this->input->post('id_pegawai', true);
            if ($data['input_idpegawai'] == 'Semua') {
                $data['filter'] = $this->db->query('SELECT * FROM pegawai')->result_array();
            } else {
                $data['filter'] = $this->db->query('SELECT * FROM pegawai WHERE id_pegawai=' . $data['input_idpegawai'])->result_array();
            }
            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pegawai', $data);
            $this->load->view('templates/footer', $data);
        }
    }

    // CETAK PEGAWAI
    public function cetakpegawai()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pegawai';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['input_idpegawai'] = $this->input->post('id_pegawai', true);

        if ($data['input_idpegawai'] == 'Semua') {
            $data['filter'] = $this->db->query('SELECT * FROM pegawai')->result_array();
        } else {
            $data['filter'] = $this->db->query('SELECT * FROM pegawai WHERE id_pegawai=' . $data['input_idpegawai'])->result_array();
        }

        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('id_pegawai', 'Pegawai', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetakpegawai', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/pegawai');
        }
    }
    // pelanggan
    public function pelanggan()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['pelanggan'] = $this->db->get('pelanggan')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get('pelanggan')->result_array();

        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pelanggan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['periode'] = $this->input->post('periode', true);
            $split = explode(' - ', $data['periode']);

            #check make sure have 2 elements in array
            $count = count($split);
            if ($count <> 2) {
                #invalid data
            }

            $dariTanggal = $split[0];
            $sampaiTanggal = $split[1];
            $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
            $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));


            $data['filter'] = $this->db->query("SELECT * FROM `pelanggan` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();

            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pelanggan', $data);
            $this->load->view('templates/footer', $data);
        }
    }
    // CETAK pelanggan
    public function cetakpelanggan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['periode'] = $this->input->post('periode', true);
        $split = explode(' - ', $data['periode']);

        #check make sure have 2 elements in array
        $count = count($split);
        if ($count <> 2) {
            #invalid data
        }

        $dariTanggal = $split[0];
        $sampaiTanggal = $split[1];
        $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
        $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));

        $data['filter'] = $this->db->query("SELECT * FROM `pelanggan` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetakpelanggan', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/pelanggan');
        }
    }
    // pelanggan kecamatan
    public function pelanggankecamatan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan Per Kecamatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['masterkecamatan'] = $this->db->get('kecamatan')->result_array();
        $data['pelanggan'] = $this->db->get('pelanggan')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('id_kecamatan', 'Kecamatan', 'required');
        //$this->form_validation->set_rules('urutan', 'Urutan', 'required');
        $data['filter'] = $this->db->query('SELECT * FROM pelanggan ORDER BY id_kecamatan ASC')->result_array();

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pelanggankecamatan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['input_idkecamatan'] = $this->input->post('id_kecamatan', true);
            if ($data['input_idkecamatan'] == 'Semua') {
                $data['filter'] = $this->db->query('SELECT * FROM pelanggan')->result_array();
            } else {
                $data['kecamatan'] = $this->Kecamatan_model->getkecamatanById($data['input_idkecamatan']);
                $data['filter'] = $this->db->query('SELECT * FROM pelanggan WHERE id_kecamatan=' . $data['input_idkecamatan'])->result_array();
            }
            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pelanggankecamatan', $data);
            $this->load->view('templates/footer', $data);
        }
    }

    // CETAK pelanggan kecamatn
    public function cetakpelanggankecamatan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan Per Kecamatan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['input_idkecamatan'] = $this->input->post('id_kecamatan', true);

        if ($data['input_idkecamatan'] == 'Semua') {
            $data['filter'] = $this->db->query('SELECT * FROM pelanggan')->result_array();
        } else {
            $data['kecamatan'] = $this->Kecamatan_model->getkecamatanById($data['input_idkecamatan']);
            $data['filter'] = $this->db->query('SELECT * FROM pelanggan WHERE id_kecamatan=' . $data['input_idkecamatan'])->result_array();
        }

        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('id_kecamatan', 'Kecamatan', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetakpelanggankecamatan', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/pegawai');
        }
    }

    // pelanggan bermasalah
    public function pelangganbermasalah()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan Bermasalah';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['pelanggan'] = $this->db->get('pelanggan')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get('pelanggan')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('laporan/pelangganbermasalah', $data);
        $this->load->view('templates/footer', $data);
    }
    // CETAK pelanggan bermasalah
    public function cetakpelangganbermasalah()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pelanggan Bermasalah';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['pelanggan'] = $this->db->get('pelanggan')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get('pelanggan')->result_array();

        $this->load->view('templates/laporan_header', $data);
        $this->load->view('laporan/cetakpelangganbermasalah', $data);
        $this->load->view('templates/laporan_footer', $data);
    }

    // stanmeter
    public function stanmeter()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeter'] = $this->db->get('stanmeter')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get('stanmeter')->result_array();

        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/stanmeter', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['periode'] = $this->input->post('periode', true);
            $split = explode(' - ', $data['periode']);

            #check make sure have 2 elements in array
            $count = count($split);
            if ($count <> 2) {
                #invalid data
            }

            $dariTanggal = $split[0];
            $sampaiTanggal = $split[1];
            $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
            $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));


            $data['filter'] = $this->db->query("SELECT * FROM `stanmeter` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();

            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/stanmeter', $data);
            $this->load->view('templates/footer', $data);
        }
    }
    // CETAK stanmeter
    public function cetakstanmeter()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['periode'] = $this->input->post('periode', true);
        $split = explode(' - ', $data['periode']);

        #check make sure have 2 elements in array
        $count = count($split);
        if ($count <> 2) {
            #invalid data
        }

        $dariTanggal = $split[0];
        $sampaiTanggal = $split[1];
        $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
        $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));

        $data['filter'] = $this->db->query("SELECT * FROM `stanmeter` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetakstanmeter', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/stanmeter');
        }
    }
    // stanmeterrusak
    public function stanmeterrusak()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Rusak/Hilang';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeterrusak'] = $this->db->get('stanmeterrusak')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get('stanmeterrusak')->result_array();

        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/stanmeterrusak', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['periode'] = $this->input->post('periode', true);
            $split = explode(' - ', $data['periode']);

            #check make sure have 2 elements in array
            $count = count($split);
            if ($count <> 2) {
                #invalid data
            }

            $dariTanggal = $split[0];
            $sampaiTanggal = $split[1];
            $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
            $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));


            $data['filter'] = $this->db->query("SELECT * FROM `stanmeterrusak` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();

            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/stanmeterrusak', $data);
            $this->load->view('templates/footer', $data);
        }
    }
    // CETAK stanmeterrusak
    public function cetakstanmeterrusak()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Rusak/Hilang';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['periode'] = $this->input->post('periode', true);
        $split = explode(' - ', $data['periode']);

        #check make sure have 2 elements in array
        $count = count($split);
        if ($count <> 2) {
            #invalid data
        }

        $dariTanggal = $split[0];
        $sampaiTanggal = $split[1];
        $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
        $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));

        $data['filter'] = $this->db->query("SELECT * FROM `stanmeterrusak` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetakstanmeterrusak', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/stanmeterrusak');
        }
    }
    // stanmeterganti
    public function stanmeterganti()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Ganti';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeterganti'] = $this->db->get('stanmeterganti')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get('stanmeterganti')->result_array();

        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/stanmeterganti', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['periode'] = $this->input->post('periode', true);
            $split = explode(' - ', $data['periode']);

            #check make sure have 2 elements in array
            $count = count($split);
            if ($count <> 2) {
                #invalid data
            }

            $dariTanggal = $split[0];
            $sampaiTanggal = $split[1];
            $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
            $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));


            $data['filter'] = $this->db->query("SELECT * FROM `stanmeterganti` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();

            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/stanmeterganti', $data);
            $this->load->view('templates/footer', $data);
        }
    }
    // CETAK stanmeterganti
    public function cetakstanmeterganti()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Stan Meter Ganti';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['periode'] = $this->input->post('periode', true);
        $split = explode(' - ', $data['periode']);

        #check make sure have 2 elements in array
        $count = count($split);
        if ($count <> 2) {
            #invalid data
        }

        $dariTanggal = $split[0];
        $sampaiTanggal = $split[1];
        $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
        $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));

        $data['filter'] = $this->db->query("SELECT * FROM `stanmeterganti` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetakstanmeterganti', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/stanmeterganti');
        }
    }

    // tagihan
    public function tagihan()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Tagihan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['stanmeter'] = $this->db->get_where('stanmeter', ['id_status' => '0'])->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get_where('stanmeter', ['id_status' => '0'])->result_array();

        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/tagihan', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['periode'] = $this->input->post('periode', true);
            $split = explode(' - ', $data['periode']);

            #check make sure have 2 elements in array
            $count = count($split);
            if ($count <> 2) {
                #invalid data
            }

            $dariTanggal = $split[0];
            $sampaiTanggal = $split[1];
            $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
            $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));


            $data['filter'] = $this->db->query("SELECT * FROM `stanmeter` WHERE `id_status`='0' AND `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();

            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/tagihan', $data);
            $this->load->view('templates/footer', $data);
        }
    }
    // CETAK tagihan
    public function cetaktagihan()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Tagihan';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['periode'] = $this->input->post('periode', true);
        $split = explode(' - ', $data['periode']);

        #check make sure have 2 elements in array
        $count = count($split);
        if ($count <> 2) {
            #invalid data
        }

        $dariTanggal = $split[0];
        $sampaiTanggal = $split[1];
        $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
        $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));

        $data['filter'] = $this->db->query("SELECT * FROM `stanmeter` WHERE `id_status`='0' AND `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetaktagihan', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/tagihan');
        }
    }

    // pembayaran
    public function pembayaran()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pembayaran';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['pembayaran'] = $this->db->get_where('pembayaran')->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();
        $data['filter'] = $this->db->get_where('pembayaran')->result_array();

        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pembayaran', $data);
            $this->load->view('templates/footer', $data);
        } else {
            $data['periode'] = $this->input->post('periode', true);
            $split = explode(' - ', $data['periode']);

            #check make sure have 2 elements in array
            $count = count($split);
            if ($count <> 2) {
                #invalid data
            }

            $dariTanggal = $split[0];
            $sampaiTanggal = $split[1];
            $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
            $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));


            $data['filter'] = $this->db->query("SELECT * FROM `pembayaran` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();

            $this->session->set_flashdata('flashdata', 'ditampilkan');
            $this->load->view('templates/header', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('laporan/pembayaran', $data);
            $this->load->view('templates/footer', $data);
        }
    }
    // CETAK pembayaran
    public function cetakpembayaran()
    {

        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Pembayaran';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);

        $data['periode'] = $this->input->post('periode', true);
        $split = explode(' - ', $data['periode']);

        #check make sure have 2 elements in array
        $count = count($split);
        if ($count <> 2) {
            #invalid data
        }

        $dariTanggal = $split[0];
        $sampaiTanggal = $split[1];
        $data['dariTanggal'] = date('Y-m-d', strtotime($dariTanggal));
        $data['sampaiTanggal'] = date('Y-m-d', strtotime($sampaiTanggal));

        $data['filter'] = $this->db->query("SELECT * FROM `pembayaran` WHERE `tanggal` BETWEEN '" . $data['dariTanggal'] . "' AND '" . $data['sampaiTanggal'] . "' ORDER BY tanggal ASC")->result_array();
        $data['profil'] = $this->db->get_where('profil')->row_array();


        $this->form_validation->set_rules('periode', 'Periode', 'required');

        if ($this->form_validation->run() == TRUE) {
            $this->load->view('templates/laporan_header', $data);
            $this->load->view('laporan/cetakpembayaran', $data);
            $this->load->view('templates/laporan_footer', $data);
        } else {
            redirect('laporan/pembayaran');
        }
    }
}
