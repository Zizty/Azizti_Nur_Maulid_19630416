<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {

        parent::__construct();
        $this->load->model('Profil_model');
        $this->load->model('Menu_model');
        $this->load->model('Submenu_model');
        $this->load->model('Level_model');
        $this->load->model('Aksesmenu_model');
        $this->load->model('Pengguna_model');
        $this->load->model('Jabatan_model');
        $this->load->model('Golpangkat_model');
        $this->load->model('Pegawai_model');

        check_login();
    }

    //BERANDA
    public function index()
    {
        $data['token'] = $this->session->userdata('token');
        $data['profil'] = $this->Profil_model->getProfil();

        $data['judul'] = 'Beranda';
        $data['pengguna'] = $this->Pengguna_model->getPenggunaByToken($data['token']);
        $data['nama_pengguna'] = $data['pengguna']['nama_pengguna'];
        $data['username'] = $data['pengguna']['username'];
        $data['id_level'] = $data['pengguna']['id_level'];
        $data['level'] = $this->Level_model->getLevelById($data['id_level']);
        $data['nama_level'] = $data['level']['nama_level'];

        $data['id_pegawai'] = $data['pengguna']['id_pegawai'];
        $data['pegawai'] = $this->Pegawai_model->getPegawaiById($data['id_pegawai']);

        $data['id_jabatan'] = $data['pegawai']['id_jabatan'];
        $data['jabatan'] = $this->Jabatan_model->getJabatanById($data['id_jabatan']);


        $data['masterpegawai'] = $this->db->get('pegawai');
        $data['masterkecamatan'] = $this->db->get('kecamatan');
        $data['masterpelanggan'] = $this->db->get('pelanggan');
        $data['masterstanmeter'] = $this->db->get('stanmeter');
        $data['profil'] = $this->db->get('profil')->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer', $data);
    }
}
