<?php

class Lampiran_model extends CI_Model
{

    public function getAlllampiran()
    {

        return $this->db->get('lampiran')->result_array();
    }

    public function getlampiranById($id_lampiran)
    {

        return $this->db->get_where('lampiran', ['id_lampiran' => $id_lampiran])->row_array();
    }

    public function tambahDatalampiran($file_baru)
    {
        $data = [
            "id_permohonan" => $this->input->post('id_permohonan', true),
            "urutan" => $this->input->post('urutan', true),
            "nama_lampiran" => $this->input->post('nama_lampiran', true),
            "lampiran" => $file_baru,
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('lampiran', $data);
    }

    public function hapusDatalampiran($id_lampiran)
    {

        //$this->db->where('id_lampiran',$id_lampiran);
        //$this->db->delete('lampiran');
        $this->db->delete('lampiran', ['id_lampiran' => $id_lampiran]);
    }
}
