<?php

class Pelanggan_model extends CI_Model
{

    public function getAllpelanggan()
    {

        return $this->db->get('pelanggan')->result_array();
    }

    public function getpelangganById($id_pelanggan)
    {

        return $this->db->get_where('pelanggan', ['id_pelanggan' => $id_pelanggan])->row_array();
    }

    public function tambahDatapelanggan()
    {

        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $tahun = date('Y', strtotime($this->input->post('tanggal')));
        $pelanggan = $this->db->order_by('id_pelanggan', 'desc')->get_where('pelanggan', ['YEAR(tanggal)' => $tahun]);
        if ($pelanggan->num_rows() <= 0) {
            $nomor_terakhir = '1';
        } else {
            $pelanggan = $this->db->order_by('id_pelanggan', 'desc')->get_where('pelanggan', ['YEAR(tanggal)' => $tahun])->row_array();
            $nomor_terakhir = substr($pelanggan['no_pelanggan'], 2, 6) + 1;
        }
        $tahun_terakhir = substr($tahun, 2, 2);

        $no_pelanggan =  $tahun_terakhir . '' . sprintf("%02s", $nomor_terakhir);

        $data = [
            "tanggal" => $tanggal,
            "no_pelanggan" => $no_pelanggan,
            "id_golongan" => $this->input->post('id_golongan', true),
            "no_stanmeter" => $this->input->post('no_stanmeter', true),
            "nik" => $this->input->post('nik', true),
            "nama_pelanggan" => $this->input->post('nama_pelanggan', true),
            "alamat" => $this->input->post('alamat', true),
            "id_kecamatan" => $this->input->post('id_kecamatan', true),
            "nohp" => $this->input->post('nohp', true),
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('pelanggan', $data);
    }
    public function ubahDatapelanggan()
    {
        $data = [
            "id_golongan" => $this->input->post('id_golongan', true),
            "no_stanmeter" => $this->input->post('no_stanmeter', true),
            "nik" => $this->input->post('nik', true),
            "nama_pelanggan" => $this->input->post('nama_pelanggan', true),
            "alamat" => $this->input->post('alamat', true),
            "id_kecamatan" => $this->input->post('id_kecamatan', true),
            "nohp" => $this->input->post('nohp', true),
            "id_status" => $this->input->post('id_status', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_pelanggan', $this->input->post('id_pelanggan', true));
        $this->db->update('pelanggan', $data);
    }
    public function hapusDatapelanggan($id_pelanggan)
    {
        $this->db->delete('pelanggan', ['id_pelanggan' => $id_pelanggan]);
    }
}
