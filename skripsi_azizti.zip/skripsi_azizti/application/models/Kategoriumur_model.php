<?php

class Kategoriumur_model extends CI_Model
{

    public function getAllkategoriumur()
    {

        return $this->db->get('kategoriumur')->result_array();
    }

    public function getkategoriumurById($id_kategoriumur)
    {

        return $this->db->get_where('kategoriumur', ['id_kategoriumur' => $id_kategoriumur])->row_array();
    }

    public function tambahDatakategoriumur()
    {

        $data = [
            "urutan" => $this->input->post('urutan', true),
            "nama_kategoriumur" => $this->input->post('nama_kategoriumur', true),
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('kategoriumur', $data);
    }

    public function ubahDatakategoriumur()
    {

        $data = [
            "id_kategoriumur" => $this->input->post('id_kategoriumur', true),
            "urutan" => $this->input->post('urutan', true),
            "nama_kategoriumur" => $this->input->post('nama_kategoriumur', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_kategoriumur', $this->input->post('id_kategoriumur', true));
        $this->db->update('kategoriumur', $data);
    }

    public function hapusDatakategoriumur($id_kategoriumur)
    {

        //$this->db->where('id_kategoriumur',$id_kategoriumur);
        //$this->db->delete('kategoriumur');
        $this->db->delete('kategoriumur', ['id_kategoriumur' => $id_kategoriumur]);
    }
}
