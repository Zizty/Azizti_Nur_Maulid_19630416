<?php

class Golongan_model extends CI_Model
{

    public function getAllgolongan()
    {

        return $this->db->get('golongan')->result_array();
    }

    public function getgolonganById($id_golongan)
    {

        return $this->db->get_where('golongan', ['id_golongan' => $id_golongan])->row_array();
    }

    public function tambahDatagolongan()
    {

        $data = [
            "urutan" => $this->input->post('urutan', true),
            "nama_golongan" => $this->input->post('nama_golongan', true),
            "beban" => $this->input->post('beban', true),
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('golongan', $data);
    }

    public function ubahDatagolongan()
    {

        $data = [
            "urutan" => $this->input->post('urutan', true),
            "nama_golongan" => $this->input->post('nama_golongan', true),
            "beban" => $this->input->post('beban', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_golongan', $this->input->post('id_golongan', true));
        $this->db->update('golongan', $data);
    }

    public function hapusDatagolongan($id_golongan)
    {

        //$this->db->where('id_golongan',$id_golongan);
        //$this->db->delete('golongan');
        $this->db->delete('golongan', ['id_golongan' => $id_golongan]);
    }
}
