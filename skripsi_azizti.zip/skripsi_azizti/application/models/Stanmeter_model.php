<?php

class Stanmeter_model extends CI_Model
{

    public function getAllstanmeter()
    {

        return $this->db->get('stanmeter')->result_array();
    }

    public function getstanmeterById($id_stanmeter)
    {

        return $this->db->get_where('stanmeter', ['id_stanmeter' => $id_stanmeter])->row_array();
    }
    public function getAlltagihan()
    {

        return $this->db->get_where('stanmeter', ['id_status' => '0'])->result_array();
    }
    public function gettagihanById($id_stanmeter)
    {

        return $this->db->get('stanmeter', ['id_stanmeter' => $id_stanmeter])->row_array();
    }

    public function tambahDatastanmeter($file_baru)
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $tahun = date('Y', strtotime($this->input->post('tanggal')));
        $bulandepan = date('m', strtotime($this->input->post('tanggal'))) + 1;
        $tgl = '20';
        $tanggal_tagihan = $tahun . '-' . $bulandepan . '-' . $tgl;
        $data = [
            "tanggal" => $tanggal,
            "tanggal_tagihan" => $tanggal_tagihan,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "indeks_sebelum" => $this->input->post('indeks_sebelum', true),
            "indeks_sekarang" => $this->input->post('indeks_sekarang', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "file" => $file_baru,
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('stanmeter', $data);
    }
    public function ubahDatastanmeter()
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $tahun = date('Y', strtotime($this->input->post('tanggal')));
        $bulandepan = date('m', strtotime($this->input->post('tanggal'))) + 1;
        $tgl = '20';
        $tanggal_tagihan = $tahun . '-' . $bulandepan . '-' . $tgl;
        $data = [
            "tanggal" => $tanggal,
            "tanggal_tagihan" => $tanggal_tagihan,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "indeks_sebelum" => $this->input->post('indeks_sebelum', true),
            "indeks_sekarang" => $this->input->post('indeks_sekarang', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_stanmeter', $this->input->post('id_stanmeter', true));
        $this->db->update('stanmeter', $data);
    }
    public function ubahDatastanmeterFile($file_baru)
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "tanggal" => $tanggal,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "indeks_sebelum" => $this->input->post('indeks_sebelum', true),
            "indeks_sekarang" => $this->input->post('indeks_sekarang', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "file" => $file_baru,
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_stanmeter', $this->input->post('id_stanmeter', true));
        $this->db->update('stanmeter', $data);
    }
    public function hapusDatastanmeter($id_stanmeter)
    {
        $this->db->delete('stanmeter', ['id_stanmeter' => $id_stanmeter]);
    }
}
