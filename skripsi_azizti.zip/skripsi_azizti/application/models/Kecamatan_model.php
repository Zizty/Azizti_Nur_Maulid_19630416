<?php

class Kecamatan_model extends CI_Model
{

    public function getAllkecamatan()
    {

        return $this->db->get('kecamatan')->result_array();
    }

    public function getkecamatanById($id_kecamatan)
    {

        return $this->db->get_where('kecamatan', ['id_kecamatan' => $id_kecamatan])->row_array();
    }

    public function tambahDatakecamatan()
    {

        $data = [
            "urutan" => $this->input->post('urutan', true),
            "nama_kecamatan" => $this->input->post('nama_kecamatan', true),
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('kecamatan', $data);
    }

    public function ubahDatakecamatan()
    {

        $data = [
            "urutan" => $this->input->post('urutan', true),
            "nama_kecamatan" => $this->input->post('nama_kecamatan', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_kecamatan', $this->input->post('id_kecamatan', true));
        $this->db->update('kecamatan', $data);
    }

    public function hapusDatakecamatan($id_kecamatan)
    {

        //$this->db->where('id_kecamatan',$id_kecamatan);
        //$this->db->delete('kecamatan');
        $this->db->delete('kecamatan', ['id_kecamatan' => $id_kecamatan]);
    }
}
