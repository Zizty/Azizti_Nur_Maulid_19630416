<?php

class Kesakitan_model extends CI_Model
{

    public function getAllkesakitan()
    {

        return $this->db->get('kesakitan')->result_array();
    }

    public function getkesakitanById($id_kesakitan)
    {

        return $this->db->get_where('kesakitan', ['id_kesakitan' => $id_kesakitan])->row_array();
    }

    public function tambahDatakesakitan()
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "id_pasien" => $this->input->post('id_pasien', true),
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('kesakitan', $data);
    }

    public function ubahDatakesakitan()
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "id_pasien" => $this->input->post('id_pasien', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_kesakitan', $this->input->post('id_kesakitan', true));
        $this->db->update('kesakitan', $data);
    }

    public function hapusDatakesakitan($id_kesakitan)
    {

        //$this->db->where('id_kesakitan',$id_kesakitan);
        //$this->db->delete('kesakitan');
        $this->db->delete('kesakitan', ['id_kesakitan' => $id_kesakitan]);
    }
}
