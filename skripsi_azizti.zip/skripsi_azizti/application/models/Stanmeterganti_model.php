<?php

class Stanmeterganti_model extends CI_Model
{

    public function getAllstanmeterganti()
    {

        return $this->db->get('stanmeterganti')->result_array();
    }

    public function getstanmetergantiById($id_stanmeterganti)
    {

        return $this->db->get_where('stanmeterganti', ['id_stanmeterganti' => $id_stanmeterganti])->row_array();
    }

    public function tambahDatastanmeterganti($file_baru)
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "tanggal" => $tanggal,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "file" => $file_baru,
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('stanmeterganti', $data);
    }
    public function ubahDatastanmeterganti()
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "tanggal" => $tanggal,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_stanmeterganti', $this->input->post('id_stanmeterganti', true));
        $this->db->update('stanmeterganti', $data);
    }
    public function ubahDatastanmetergantiFile($file_baru)
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $data = [
            "tanggal" => $tanggal,
            "id_pelanggan" => $this->input->post('id_pelanggan', true),
            "id_pegawai" => $this->input->post('id_pegawai', true),
            "keterangan" => $this->input->post('keterangan', true),
            "file" => $file_baru,
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_stanmeterganti', $this->input->post('id_stanmeterganti', true));
        $this->db->update('stanmeterganti', $data);
    }
    public function hapusDatastanmeterganti($id_stanmeterganti)
    {
        $this->db->delete('stanmeterganti', ['id_stanmeterganti' => $id_stanmeterganti]);
    }
}
