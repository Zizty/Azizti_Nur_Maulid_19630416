<?php

class Pembayaran_model extends CI_Model
{

    public function getAllpembayaran()
    {

        return $this->db->get('pembayaran')->result_array();
    }

    public function getpembayaranById($id_pembayaran)
    {

        return $this->db->get_where('pembayaran', ['id_pembayaran' => $id_pembayaran])->row_array();
    }
    public function getAlltagihan()
    {

        return $this->db->get('pembayaran', ['id_status' => '0'])->result_array();
    }
    public function gettagihanById($id_pembayaran)
    {

        return $this->db->get('pembayaran', ['id_pembayaran' => $id_pembayaran])->row_array();
    }

    public function tambahDatapembayaran($id_stanmeter)
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $biaya_admin = $this->input->post('biaya_admin', true);
        $biaya_admin = str_replace("Rp. ", "", $biaya_admin);
        $biaya_admin = str_replace(".", "", $biaya_admin);
        $biaya_pemakaian = $this->input->post('biaya_pemakaian', true);
        $biaya_pemakaian = str_replace("Rp. ", "", $biaya_pemakaian);
        $biaya_pemakaian = str_replace(".", "", $biaya_pemakaian);
        $total_tagihan = $this->input->post('total_tagihan', true);
        $total_tagihan = str_replace("Rp. ", "", $total_tagihan);
        $total_tagihan = str_replace(".", "", $total_tagihan);
        $data = [
            "tanggal" => $tanggal,
            "kode" => random_string('alnum', 10),
            "id_stanmeter" => $id_stanmeter,
            "biaya_admin" => $biaya_admin,
            "biaya_pemakaian" => $biaya_pemakaian,
            "total_tagihan" => $total_tagihan,
            "keterangan" => $this->input->post('keterangan', true),
            "user_input" => check_username(),
            "tgl_input" => date('Y-m-d h:m:i')
        ];
        $this->db->insert('pembayaran', $data);

        $data = [
            "id_status" => "1",
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_stanmeter', $id_stanmeter);
        $this->db->update('stanmeter', $data);
    }
    public function ubahDatapembayaran()
    {
        $tanggal = date('Y-m-d', strtotime($this->input->post('tanggal')));
        $biaya_admin = $this->input->post('biaya_admin', true);
        $biaya_admin = str_replace("Rp. ", "", $biaya_admin);
        $biaya_admin = str_replace(".", "", $biaya_admin);
        $biaya_pemakaian = $this->input->post('biaya_pemakaian', true);
        $biaya_pemakaian = str_replace("Rp. ", "", $biaya_pemakaian);
        $biaya_pemakaian = str_replace(".", "", $biaya_pemakaian);
        $total_tagihan = $this->input->post('total_tagihan', true);
        $total_tagihan = str_replace("Rp. ", "", $total_tagihan);
        $total_tagihan = str_replace(".", "", $total_tagihan);
        $data = [
            "tanggal" => $tanggal,
            "kode" => random_string('alnum', 10),
            "id_stanmeter" => $this->input->post('id_stanmeter', true),
            "biaya_admin" => $biaya_admin,
            "biaya_pemakaian" => $biaya_pemakaian,
            "total_tagihan" => $total_tagihan,
            "keterangan" => $this->input->post('keterangan', true),
            "user_ubah" => check_username(),
            "tgl_ubah" => date('Y-m-d h:m:i')
        ];
        $this->db->where('id_pembayaran', $this->input->post('id_pembayaran', true));
        $this->db->update('pembayaran', $data);
    }

    public function hapusDatapembayaran($id_pembayaran)
    {
        $this->db->delete('pembayaran', ['id_pembayaran' => $id_pembayaran]);
    }
    public function hapusDatapembayaranByIdStan($id_stanmeter)
    {
        $this->db->delete('pembayaran', ['id_stanmeter' => $id_stanmeter]);
    }
}
